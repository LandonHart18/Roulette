﻿using System;
using System.Security.Cryptography.X509Certificates;
using Roulette.Bets;

namespace Roulette
{
    public class Menu
    {
        public string Guess { get; set; }
        public int NumberGuess { get; set; }
        public void BetMenu(string color, int number)
        {
            
            Console.WriteLine("Please select one of the following bets below:");
            Console.WriteLine("a.Even    b.Odd     c.Low        d.High");
            Console.WriteLine("e.Red     f.Black   g.1st 12     h.2nd 12");
            Console.WriteLine("i.3rd 12  j.Split   k.Corner     l.Number");
            Console.WriteLine("m.1st 6   n.2nd 6   o.3rd 6      p.4th 6");
            Console.WriteLine("q.5th 6   r.6th 6   s.1st Column t. 2nd Column");
            Console.WriteLine("u.3rd Column  v.Street");
            Guess = (Console.ReadLine());
            Guess.ToLower();

            bool[] conditions =
            {
            Guess == "a", Guess == "b", Guess == "c", Guess == "d", Guess == "e", Guess == "f", Guess == "g",
            Guess == "h", Guess == "i", Guess == "j", Guess == "k", Guess =="l", Guess == "m", Guess == "n", 
            Guess == "o", Guess =="p", Guess == "q", Guess == "r", Guess =="s", Guess == "t", Guess == "u",
            Guess == "v"};
            int check = Array.IndexOf(conditions, true);
            while (check == -1)
            {
            Console.WriteLine("\nYou did not enter a valid option, please select a-v.");
            Console.WriteLine("\nPlease try again.");
            Console.ReadKey();
            }

            string temp;
            int tempNum;

            if (Guess == "j" || Guess == "k" || Guess == "l" || Guess == "v")
            {
                Console.WriteLine("Please pick a number between 1-36:");
                temp = Console.ReadLine();
                int.TryParse(temp, out tempNum);
                NumberGuess = tempNum;
            }

            #region EvenOdd

            if (Guess == "a")
            {
                EvenOdd evenOdd = new EvenOdd();
                evenOdd.CalculateWin(Guess, number);
            }
            else if (Guess == "b")
            {
                EvenOdd evenOdd = new EvenOdd();
                evenOdd.CalculateWin(Guess, number);
            }

            #endregion

            #region RedBlack

            if (Guess == "e")
            {
                RedBlack redBlack = new RedBlack();
                redBlack.CalculateWin(Guess, color);
            }
            else if (Guess == "f")
            {
                RedBlack redBlack = new RedBlack();
                redBlack.CalculateWin(Guess, color);
            }

            #endregion

            #region LowHigh

            if (Guess == "c")
            {
                LowHigh lowHigh = new LowHigh();
                lowHigh.CalculateWin(Guess, number);
            }
            else if (Guess == "d")
            {
                LowHigh lowHigh = new LowHigh();
                lowHigh.CalculateWin(Guess, number);
            }

            #endregion

            #region Dozens

            if (Guess == "g")
            {
                Dozens dozens = new Dozens();
                dozens.CalculateWin(Guess, number);
            }
            else if (Guess == "h")
            {
                Dozens dozens = new Dozens();
                dozens.CalculateWin(Guess, number);
            }
            else if (Guess == "i")
            {
                Dozens dozens = new Dozens();
                dozens.CalculateWin(Guess, number);
            }

            #endregion

            #region SixNumbers

            if (Guess == "m")
            {
                SixNumbers sixNumbers = new SixNumbers();
                sixNumbers.CalculateWin(Guess, number);
            }
            else if (Guess == "n")
            {
                SixNumbers sixNumbers = new SixNumbers();
                sixNumbers.CalculateWin(Guess, number);
            }
            else if (Guess == "o")
            {
                SixNumbers sixNumbers = new SixNumbers();
                sixNumbers.CalculateWin(Guess, number);
            }
            else if (Guess == "p")
            {
                SixNumbers sixNumbers = new SixNumbers();
                sixNumbers.CalculateWin(Guess, number);
            }
            else if (Guess == "q")
            {
                SixNumbers sixNumbers = new SixNumbers();
                sixNumbers.CalculateWin(Guess, number);
            }
            else if (Guess == "r")
            {
                SixNumbers sixNumbers = new SixNumbers();
                sixNumbers.CalculateWin(Guess, number);
            }

            #endregion

            #region Columns

            if (Guess == "m")
            {
                Columns columns = new Columns();
                columns.CalculateWin(Guess, number);
            }
            else if (Guess == "n")
            {
                Columns columns = new Columns();
                columns.CalculateWin(Guess, number);
            }
            else if (Guess == "o")
            {
                Columns columns = new Columns();
                columns.CalculateWin(Guess, number);
            }

            #endregion

            #region Corners

            if (NumberGuess == 1)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 3)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 7)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 9)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 13)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 15)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 19)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 21)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 25)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 27)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 31)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 33)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }

            #endregion

            #region Numbers

            if (NumberGuess == 1)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 2)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 3)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 4)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 5)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 6)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 7)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 8)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 9)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 10)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 11)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number); ;
            }
            else if (NumberGuess == 12)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 13)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 14)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 15)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 16)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 17)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 18)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 19)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 20)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 21)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 22)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 23)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 24)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 25)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 26)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 27)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 28)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 29)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 30)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 31)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 32)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 33)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 34)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 35)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 36)
            {
                Numbers numbers = new Numbers();
                numbers.CalculateWin(NumberGuess, number);
            }

            #endregion

            #region Splits

            if (NumberGuess == 1)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 2)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 4)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 5)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 7)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 8)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 10)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 11)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 13)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 14)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 16)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 17)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 19)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 20)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 22)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 23)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 25)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 27)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 28)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 29)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 31)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 33)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 34)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 35)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }

            #endregion

            #region Streets

            if (NumberGuess == 1)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 4)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 7)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 10)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 13)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 16)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 19)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 22)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 25)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 28)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 31)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }
            else if (NumberGuess == 34)
            {
                Corners corners = new Corners();
                corners.CalculateWin(NumberGuess, number);
            }

            #endregion
        }
    }
}
