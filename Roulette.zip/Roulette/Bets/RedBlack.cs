﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Roulette.Bets
{
    class RedBlack
    {

        public void CalculateWin(string guess, string color)
        {

            if (guess == "e" && color == "Red")
            {
                Console.WriteLine("The roulette rolled: " + " " + color);
                Console.WriteLine("You won!");
            }
            else if (guess == "f" && color == "Black")
            {
                Console.WriteLine("The roulette rolled: " + " " + color);
                Console.WriteLine("You won!");
            }
            else if (guess == "e" || guess == "f")
            {
                Console.WriteLine("You Lose!");
            }

        }
    }
}
