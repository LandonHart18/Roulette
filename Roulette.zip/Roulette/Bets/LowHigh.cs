﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Roulette.Bets
{
    class LowHigh
    {
        public void CalculateWin(string guess, int number)
        {

            if ((guess == "c") && ((number > 0) && (number < 19)))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((guess == "d") && ((number > 18) && (number < 37)))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if (guess == "c" || guess == "d")
            {
                Console.WriteLine("You Lose!");
            }

        }
    }
}
