﻿using System;

namespace Roulette.Bets
{
    class EvenOdd
    {
        public bool EvenOddWin { get; set; }
        public void CalculateWin(string guess, int number)
        {

            if ( guess == "a" && number % 2 == 0)
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if (guess == "b" && number % 2 == 1)
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if (guess == "a" || guess == "b")
            {
                Console.WriteLine("You Lose!");
            }

        }

    }
}
