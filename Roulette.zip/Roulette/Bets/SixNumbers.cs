﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Roulette.Bets
{
    class SixNumbers
    {
        public void CalculateWin(string guess, int number)
        {

            if ((guess == "m") && (number > 0 && number < 7))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((guess == "n") && (number > 6 && number < 13))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((guess == "o") && (number > 12 && number < 19))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((guess == "p") && (number > 18 && number < 25))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((guess == "q") && (number > 24 && number < 31))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((guess == "r") && (number > 30 && number < 37))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if (guess == "m" || guess == "n" || guess == "o" || guess == "p" || guess == "q" || guess == "r")
            {
                Console.WriteLine("You Lose!");
            }
        }
    }
}
