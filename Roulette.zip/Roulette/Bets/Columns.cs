﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Roulette.Bets
{
    class Columns
    {
        public void CalculateWin(string guess, int number)
        {

            if ((guess == "s") && (number == 1 || number == 4 || number == 7 || number == 10 || number == 13 || number == 16 || number == 19 || number== 22 || number == 25 || number == 28 || number == 31 || number == 34 ))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((guess == "t") && (number == 2 || number == 5 || number == 8 || number == 11 || number == 14 || number == 17 || number == 20 || number == 23 || number == 26 || number == 29 || number == 32 || number == 35))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((guess == "u") && (number == 3 || number == 6 || number == 9 || number == 12 || number == 15 || number == 18 || number == 21 || number == 24 || number == 27 || number == 30 || number == 33 || number == 36))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if (guess == "s" || guess == "t" || guess == "u")
            {
                Console.WriteLine("You Lose!");
            }
        }
    }
}
