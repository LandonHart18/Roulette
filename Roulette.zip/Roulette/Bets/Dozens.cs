﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Roulette.Bets
{
    class Dozens
    {
        public void CalculateWin(string guess, int number)
        {

            if ((guess == "g") && (number > 0 && number < 13))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((guess == "h") && (number > 12 && number < 25))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((guess == "i") && (number > 24 && number < 37))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if (guess == "h" || guess == "i" || guess == "j")
            {
                Console.WriteLine("You Lose!");
            }
        }
    }
}