﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Roulette.Bets
{
    class Numbers
    {
        public void CalculateWin(int numberGuess, int number)
        {

            if ((numberGuess == 1))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 2))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 3))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 4))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 5))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 6))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 7))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 8))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 9))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 10))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 11))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 12))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 13))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 14))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 15))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 16))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 17))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 18))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 19))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 20))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 21))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 22))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 23))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 24))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 25))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 26))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 27))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 28))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 29))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 30))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 31))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 32))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 33))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 34))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 35))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 36))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 1 || numberGuess == 2 || numberGuess == 3 || numberGuess == 4 ||  numberGuess == 5 || numberGuess == 6 || numberGuess == 7 || numberGuess == 8 || numberGuess == 9 || numberGuess == 10 || numberGuess == 11 || numberGuess == 12
            || numberGuess == 13 || numberGuess == 14 || numberGuess == 15 || numberGuess == 16 || numberGuess == 17 || numberGuess == 18 || numberGuess == 19 || numberGuess == 20 || numberGuess == 21 || numberGuess == 22 || numberGuess == 23 || numberGuess == 24
            || numberGuess == 25 || numberGuess == 26 || numberGuess == 27 || numberGuess == 28 || numberGuess == 29 || numberGuess == 30 || numberGuess == 31 || numberGuess == 32 || numberGuess == 33 || numberGuess == 34 || numberGuess == 35 || numberGuess == 36))
            {
                Console.WriteLine("You Lose!");
            }
        }
    }
}
