﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Roulette.Bets
{
    class Corners
    {
        public void CalculateWin(int numberGuess, int number)
        {

            if ((numberGuess == 1) && (number == 1 || number == 2 || number == 4 || number == 5))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 3) && (number == 2 || number == 3 || number == 5 || number == 6))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 7) && (number == 7 || number == 8 || number == 10 || number == 11))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 9) && (number == 8 || number == 9 || number == 11 || number == 12))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 13) && (number == 13 || number == 14 || number == 16 || number == 17))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 15) && (number == 14 || number == 15 || number == 17 || number == 18))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 19) && (number == 19 || number == 20 || number == 22 || number == 23))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 21) && (number == 20 || number == 21 || number == 23 || number == 24))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 25) && (number == 25 || number == 26 || number == 28 || number == 29))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 27) && (number == 26 || number == 27 || number == 29 || number == 30))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 31) && (number == 31 || number == 32 || number == 34 || number == 35))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if ((numberGuess == 33) && (number == 32 || number == 33 || number == 35 || number == 36))
            {
                Console.WriteLine("The roulette rolled: " + " " + number);
                Console.WriteLine("You won!");
            }
            else if (numberGuess == 1 || numberGuess == 3 || numberGuess == 7 || numberGuess == 9 || numberGuess == 13 || numberGuess == 15 || numberGuess == 19 || numberGuess == 21 || numberGuess == 25 || numberGuess == 27 || numberGuess == 31 || numberGuess == 33)
            {
                Console.WriteLine("You Lose!");
            }
        }
    }
}
