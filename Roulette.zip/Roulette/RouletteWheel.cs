﻿using System;

namespace Roulette
{
    class RouletteWheel
    {
        public string Color { get; set; }

        public int Number { get; set; }

        public void RollRouletteWheel()
        {
            Random ran = new Random();
            int[] number = new int[38] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 0 };
            int roll = ran.Next(0, 38);

            string[] color = new string[38];
            color[0] = "Green";
            color[37] = "Green";
            for (int i = 1; i < 19; i++)
            {
                color[i] = "Red";
            }

            for (int i = 20; i < 37; i++)
            {
                color[i] = "Black";
            }

            Color = color[roll];
            Number = number[roll];


        }



    }
}
