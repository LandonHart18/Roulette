﻿using System;

namespace Roulette
{
    class Program
    {
        static void Main(string[] args)
        {
            RouletteWheel rouletteWheel = new RouletteWheel();
            rouletteWheel.RollRouletteWheel();
            Menu menu = new Menu();
            menu.BetMenu(rouletteWheel.Color, rouletteWheel.Number);
            WinLoss winLoss = new WinLoss();
            winLoss.PossibleWins(rouletteWheel.Color, menu.NumberGuess, rouletteWheel.Number);
        }

    }
}


