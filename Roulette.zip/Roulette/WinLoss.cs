﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Roulette
{
    class WinLoss
    {
        public void PossibleWins(string color, int numberGuess, int tableNumber)
        {
            Program program = new Program();
            Console.WriteLine("The roulette rolled: " + color + " " + tableNumber);
            Console.WriteLine("Possible winning bets are:");

            #region EvenOdd

            if (tableNumber % 2 == 0)
            {
                Console.WriteLine("Even");
            }
            else if (tableNumber % 2 == 1)
            {
                Console.WriteLine("Odd");
            }

            #endregion

            #region RedBlack

            if (color == "Red")
            {
                Console.WriteLine("Red");
            }
            else if (color == "Black")
            {
                Console.WriteLine("Black");
            }

            #endregion

            #region LowHigh

            if ((tableNumber > 0) && (tableNumber < 19))
            {
                Console.WriteLine("Low");
            }
            else if ((tableNumber > 18) && (tableNumber < 37))
            {
                Console.WriteLine("High");
            }

            #endregion

            #region Dozens

            if ((tableNumber > 0 && tableNumber < 13))
            {
                Console.WriteLine("1st 12");
            }
            else if (tableNumber > 12 && tableNumber < 25)
            {
                Console.WriteLine("2nd 12");
            }
            else if ((tableNumber > 24 && tableNumber < 37))
            {
                Console.WriteLine("3rd 12");
            }

            #endregion

            #region SixNumbers

            if ((tableNumber > 0 && tableNumber < 7))
            {
                Console.WriteLine("1st 6");
            }
            else if (tableNumber > 6 && tableNumber < 13)
            {
                Console.WriteLine("2nd 6");
            }
            else if ((tableNumber > 12 && tableNumber < 19))
            {
                Console.WriteLine("3rd 6");
            }
            else if (tableNumber > 18 && tableNumber < 25)
            {
                Console.WriteLine("4th 6");
            }
            else if ((tableNumber > 24 && tableNumber < 31))
            {
                Console.WriteLine("5th 6");
            }
            else if (tableNumber > 30 && tableNumber < 37)
            {
                Console.WriteLine("6th 6");
            }

            #endregion

            #region Columns

            if (tableNumber == 1 || tableNumber == 4 || tableNumber == 7 || tableNumber == 10 || tableNumber == 13 || tableNumber == 16 || tableNumber == 19 || tableNumber == 22 || tableNumber == 25 || tableNumber == 28 || tableNumber == 31 || tableNumber == 34)
            {
                Console.WriteLine("1st 12");
            }
            else if (tableNumber == 2 || tableNumber == 5 || tableNumber == 8 || tableNumber == 11 || tableNumber == 14 || tableNumber == 17 || tableNumber == 20 || tableNumber == 23 || tableNumber == 26 || tableNumber == 29 || tableNumber == 32 || tableNumber == 35)
            {
                Console.WriteLine("2nd 12");
            }
            else if (tableNumber == 3 || tableNumber == 6 || tableNumber == 9 || tableNumber == 12 || tableNumber == 15 || tableNumber == 18 || tableNumber == 21 || tableNumber == 24 || tableNumber == 27 || tableNumber == 30 || tableNumber == 33 || tableNumber == 36)
            {
                Console.WriteLine("3rd 12");
            }

            #endregion

            #region Corners

            if ((tableNumber == 1 || tableNumber == 2 || tableNumber == 4 || tableNumber == 5))
            {
                Console.WriteLine("Corners");
            }
            else if ((tableNumber == 2 || tableNumber == 3 || tableNumber == 5 || tableNumber == 6))
            {
                Console.WriteLine("Corners");
            }
            else if ((tableNumber == 7 || tableNumber == 8 || tableNumber == 10 || tableNumber == 11))
            {
                Console.WriteLine("Corners");
            }
            else if ((tableNumber == 8 || tableNumber == 9 || tableNumber == 11 || tableNumber == 12))
            {
                Console.WriteLine("Corners");
            }
            else if ((tableNumber == 13 || tableNumber == 14 || tableNumber == 16 || tableNumber == 17))
            {
                Console.WriteLine("Corners");
            }
            else if ((tableNumber == 14 || tableNumber == 15 || tableNumber == 17 || tableNumber == 18))
            {
                Console.WriteLine("Corners");
            }
            else if ((tableNumber == 19 || tableNumber == 20 || tableNumber == 22 || tableNumber == 23))
            {
                Console.WriteLine("Corners");
            }
            else if ((tableNumber == 20 || tableNumber == 21 || tableNumber == 23 || tableNumber == 24))
            {
                Console.WriteLine("Corners");
            }
            else if ((tableNumber == 25 || tableNumber == 26 || tableNumber == 28 || tableNumber == 29))
            {
                Console.WriteLine("Corners");
            }
            else if ((tableNumber == 26 || tableNumber == 27 || tableNumber == 29 || tableNumber == 30))
            {
                Console.WriteLine("Corners");
            }
            else if ((tableNumber == 31 || tableNumber == 32 || tableNumber == 34 || tableNumber == 35))
            {
                Console.WriteLine("Corners");
            }
            else if ((tableNumber == 32 || tableNumber == 33 || tableNumber == 35 || tableNumber == 36))
            {
                Console.WriteLine("Corners");
            }

            #endregion

            #region Numbers

            if ((numberGuess == 1))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 2))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 3))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 4))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 5))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 6))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 7))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 8))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 9))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 10))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 11))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 12))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 13))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 14))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 15))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 16))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 17))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 18))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 19))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 20))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 21))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 22))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 23))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 24))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 25))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 26))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 27))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 28))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 29))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 30))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 31))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 32))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 33))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 34))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 35))
            {
                
                Console.WriteLine("Number");
            }
            else if ((numberGuess == 36))
            {
                
                Console.WriteLine("Number");
            }

            #endregion

            #region Splits

            if (tableNumber == 1 || tableNumber == 2)
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 2 || tableNumber == 3))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 4 || tableNumber == 5))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 5 || tableNumber == 6))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 7 || tableNumber == 8))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 8 || tableNumber == 9))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 10 || tableNumber == 11))
            {
                
                Console.WriteLine("Splits");
            }
            else if (tableNumber == 11 || tableNumber == 12)
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 13 || tableNumber == 14))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 14 || tableNumber == 15))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 16 || tableNumber == 17))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 17 || tableNumber == 18))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 19 || tableNumber == 20))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 20 || tableNumber == 21))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 22 || tableNumber == 23))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 23 || tableNumber == 24))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 25 || tableNumber == 26))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 26 || tableNumber == 27))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 28 || tableNumber == 29))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 29 || tableNumber == 30))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 31 || tableNumber == 32))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 32 || tableNumber == 33))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 34 || tableNumber == 35))
            {
                
                Console.WriteLine("Splits");
            }
            else if ((tableNumber == 35 || tableNumber == 36))
            {
                
                Console.WriteLine("Splits");
            }

            #endregion

            #region Streets

            if ((tableNumber == 1 || tableNumber == 2 || tableNumber == 3))
            {
                
                Console.WriteLine("Streets");
            }
            else if ((tableNumber == 4 || tableNumber == 5 || tableNumber == 6))
            {
                
                Console.WriteLine("Streets");
            }
            else if ((tableNumber == 7 || tableNumber == 8 || tableNumber == 9))
            {
                
                Console.WriteLine("Streets");
            }
            else if ((tableNumber == 10 || tableNumber == 11 || tableNumber == 12))
            {
                
                Console.WriteLine("Streets");
            }
            else if ((tableNumber == 13 || tableNumber == 14 || tableNumber == 15))
            {
                
                Console.WriteLine("Streets");
            }
            else if ((tableNumber == 16 || tableNumber == 17 || tableNumber == 18))
            {
                
                Console.WriteLine("Streets");
            }
            else if ((tableNumber == 19 || tableNumber == 20 || tableNumber == 21))
            {
                
                Console.WriteLine("Streets");
            }
            else if ((tableNumber == 22 || tableNumber == 23 || tableNumber == 24))
            {
                
                Console.WriteLine("Streets");
            }
            else if ((tableNumber == 25 || tableNumber == 26 || tableNumber == 27))
            {
                
                Console.WriteLine("Streets");
            }
            else if ((tableNumber == 28 || tableNumber == 29 || tableNumber == 30))
            {
                
                Console.WriteLine("Streets");
            }
            else if ((tableNumber == 31 || tableNumber == 32 || tableNumber == 33))
            {
                
                Console.WriteLine("Streets");
            }
            else if ((tableNumber == 34 || tableNumber == 35 || tableNumber == 36))
            {
                
                Console.WriteLine("Streets");
            }

        }

        #endregion

    }

}